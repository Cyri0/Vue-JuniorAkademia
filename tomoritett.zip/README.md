# vue-juniorakademia

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

### JSON file with datas
Make a my_data.json file in the src/ folder with the following datas (from www.emailjs.com):

[
    {
        "SERVICE_ID": "",
        "USER_ID": "",
        "TEMPLATE_ID_MESSAGE": "",
        "TEMPLATE_ID_APPLY" : ""

    }
]