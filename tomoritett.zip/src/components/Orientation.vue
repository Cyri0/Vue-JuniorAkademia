<template>
  <div class="page green_page">
    <div class="board">
      <h1 class="title">Pályaorientáció</h1>
      <h2 class="fade-in">Hamarosan...</h2>
    </div>
    <div class="mandatory">
      ©2020 Junior Akadémia
      <br />
      <router-link to="/DataManagementStatement/">ÁSZF és Adatkezelési Nyilatkozat</router-link>
    </div>
  </div>
</template>

<script>
export default {

}
</script>


<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h2{
  margin-top: 150px;
  text-align: center;
}

</style>
